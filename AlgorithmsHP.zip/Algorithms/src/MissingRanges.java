import java.util.ArrayList;
import java.util.List;

/**
 * Created by 310288079 on 7/7/2017.
 */
public class MissingRanges {
    public List<String> solve(int[] nums, int lowerbount, int upperbount){
        List<String> res = new ArrayList<String>();
        return res;
    }

    public static void main(String[] args){
        MissingRanges missingRanges = new MissingRanges();
        missingRanges.solve(new int[]{0, 1, 3, 50, 75}, 0, 99);
    }
}
