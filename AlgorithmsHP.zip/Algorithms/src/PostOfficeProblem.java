/**
 * Created by 310288079 on 7/15/2017.
 */
public class PostOfficeProblem {
    private void computeDistance(int[] houses){
        int len = houses.length;
        int[][] distance = new int[len][len];

        for(int interval = 0; interval < len; interval ++){
            
        }
    }
}
