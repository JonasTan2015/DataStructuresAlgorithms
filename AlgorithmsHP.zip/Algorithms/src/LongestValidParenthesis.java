import java.util.Stack;

/**
 * Created by 310288079 on 6/18/2017.
 */
public class LongestValidParenthesis {
//    public int solution(String s){
//        Stack<Node> stack = new Stack<Node>();
//        for(int i = 0; i < s.length(); i ++) {
//            char ch = s.charAt(i);
//            if (ch == '(') {
//                stack.push(new Node(ch, i));
//            }
//        }
//    }
//
//    private class Node {
//        char ch = '0';
//        int index = 0;
//        Node(char ch, int index){
//            this.ch = ch;
//            this.index = index;
//        }
//    }
}
