import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by 310288079 on 7/5/2017.
 */
public class WordsAbbreviation {


}
