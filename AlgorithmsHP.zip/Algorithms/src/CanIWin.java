/**
 * Created by 310288079 on 7/16/2017.
 */
public class CanIWin {

    public boolean solve(int n, int target){
        return true;
    }
}
